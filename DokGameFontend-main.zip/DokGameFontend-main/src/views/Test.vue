<template>
    <nav class="navbar navbar-expand navbar-dark bg-dark">
      <a href="/" class="navbar-brand">Ứng dụng Quản lý danh bạ</a>
      <div class="mr-auto navbar-nav">
        <li class="nav-item">
            <i class="fas fa-address-book"></i>
        </li>
      </div>
    </nav>
  </template>
  